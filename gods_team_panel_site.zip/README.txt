INSTALL & PUBLISH
1) Replace phonepe_qr.png with your actual PhonePe QR image (filename must match).
2) Upload these files (index.html, style.css, phonepe_qr.png) to your GitHub Pages repo root.
3) If you want voice intro or extra customizations ask me and I'll add them.
